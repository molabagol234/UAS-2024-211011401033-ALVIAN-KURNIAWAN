package com.example.crypto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
